package panzer.constants;

public class GlobalConstants {

    private GlobalConstants(){}

    public static final String TERMINATE_OUTPUT_COMMAND = "Terminate";

}
