package panzer.manager;

import panzer.annotations.Inject;
import panzer.contracts.*;
import panzer.core.PanzerBattleOperator;
import panzer.enums.PartType;
import panzer.factories.PartFactory;
import panzer.factories.VehicleFactory;
import panzer.models.parts.ArsenalPart;
import panzer.models.parts.EndurancePart;
import panzer.models.parts.ShellPart;
import panzer.models.vehicles.Revenger;
import panzer.models.vehicles.Vanguard;

import java.math.BigDecimal;
import java.util.*;
import java.util.stream.Collectors;

public class ProgramManager implements Manager {

//    private static final String CREATED_VEHICLE_MESSAGE = "Created %s Vehicle - %s";
//    private static final String CREATED_PART_MESSAGE = "Added %s - %s to Vehicle - %s";
//    private static final String BATTLE_MESSAGE = "%s versus %s -> %s Wins! Flawless Victory!";
//
//    private Map<String, Vehicle> remainingVehicles;
//    private Map<String, Vehicle> defeatedVehicles;
//    private Map<String, Part> parts;
//
//    @Inject
//    private BattleOperator battleOperator;
//
//    public ProgramManager() {
//        this.remainingVehicles = new LinkedHashMap<>();
//        this.defeatedVehicles = new LinkedHashMap<>();
//        this.parts = new LinkedHashMap<>();
//    }
//
//    @Override
//    public String addVehicle(List<String> arguments) {
//
//        Vehicle vehicle = VehicleFactory.createVehicle(arguments);
//        this.remainingVehicles.put(vehicle.getModel(), vehicle);
//
//        return String.format(CREATED_VEHICLE_MESSAGE, arguments.get(1), arguments.get(2));
//    }
//
//    @Override
//    public String addPart(List<String> arguments) {
//
//        String vehicleToAddPartToStr = arguments.get(1);
//        PartType partType = Enum.valueOf(PartType.class, arguments.get(2).toUpperCase());
//        switch (partType) {
//            case ARSENAL:
//
//                AttackModifyingPart attackModifyingPart = (AttackModifyingPart) PartFactory.createPart(arguments);
//
//
//                this.parts.put(attackModifyingPart.getModel(), attackModifyingPart);
//                this.remainingVehicles.get(vehicleToAddPartToStr).addArsenalPart(attackModifyingPart);
//                break;
//
//            case ENDURANCE:
//
//                HitPointsModifyingPart hitPointsModifyingPart = (HitPointsModifyingPart) PartFactory.createPart(arguments);
//
//
//                this.parts.put(hitPointsModifyingPart.getModel(), hitPointsModifyingPart);
//                this.remainingVehicles.get(vehicleToAddPartToStr).addEndurancePart(hitPointsModifyingPart);
//                break;
//
//            case SHELL:
//
//                DefenseModifyingPart defenseModifyingPart = (DefenseModifyingPart) PartFactory.createPart(arguments);
//
//
//                this.parts.put(defenseModifyingPart.getModel(), defenseModifyingPart);
//                this.remainingVehicles.get(vehicleToAddPartToStr).addShellPart(defenseModifyingPart);
//                break;
//        }
//        return String.format(CREATED_PART_MESSAGE,
//                arguments.get(2),
//                arguments.get(3),
//                arguments.get(1));
//    }
//
//    @Override
//    @SuppressWarnings("unchecked")
//    public String inspect(List<String> arguments) {
//        String result;
//
//        String model = arguments.get(1);
//
//        if (this.remainingVehicles.containsKey(model)) {
//            result = this.remainingVehicles.get(model).toString();
//        } else {
//            result = this.parts.get(model).toString();
//        }
//        return result;
//    }
//
//    @Override
//    public String battle(List<String> arguments) {
//
//        Vehicle attacker = this.remainingVehicles.get(arguments.get(1));
//        Vehicle target = this.remainingVehicles.get(arguments.get(2));
//
//        String winner = this.battleOperator.battle(attacker, target);
//        String loser = (winner.equals(attacker.getModel())) ? target.getModel() : attacker.getModel();
//
//        this.defeatedVehicles.put(loser, this.remainingVehicles.get(loser));
//        this.remainingVehicles.remove(loser);
//
//        return String.format(BATTLE_MESSAGE, attacker.getModel(), target.getModel(), winner);
//    }
//
//    @Override
//    public String terminate(List<String> arguments) {
//
//        StringBuilder sb = new StringBuilder();
//        sb.append("Remaining Vehicles: ");
//
//
//        String remainingVehiclesStr = (!this.remainingVehicles.isEmpty())
//                ? this.remainingVehicles.values().stream().map(Vehicle::getModel).collect(Collectors.joining(", "))
//                : "None";
//
//        sb
//                .append(remainingVehiclesStr).append(System.lineSeparator())
//                .append("Defeated Vehicles: ");
//
//
//        String defeatedVehiclesStr = (!this.defeatedVehicles.isEmpty())
//                ? this.defeatedVehicles.values().stream().map(Vehicle::getModel).collect(Collectors.joining(", "))
//                : "None";
//
//        sb
//                .append(defeatedVehiclesStr).append(System.lineSeparator())
//                .append("Currently Used Parts: ");
//
//        long usedParts = this.remainingVehicles.values()
//
//                .stream()
//                .mapToLong(vehicle -> ((List<Part>) vehicle.getParts()).size()).sum();
//
//        sb.append(usedParts);
//
//        return sb.toString();
//    }

    private HashMap<String, Vehicle> vehicles;
    private List<String> defeatedVehicles;
    private List<String> remainingVehicles;
    private HashMap<String, Part> parts;
    private BattleOperator battleOperator;

    public ProgramManager() {
        this.vehicles = new LinkedHashMap<>();
        this.battleOperator = new PanzerBattleOperator();
        this.parts = new LinkedHashMap<>();
        this.defeatedVehicles = new LinkedList<>();
        this.remainingVehicles = new LinkedList<>();
    }

    @Override
    public String addVehicle(List<String> arguments) {
        switch (arguments.get(1)) {
            case "Revenger":
                Vehicle revenger = new Revenger(
                        arguments.get(2),
                        Double.parseDouble(arguments.get(3)),
                        new BigDecimal(arguments.get(4)),
                        Integer.parseInt(arguments.get(5)),
                        Integer.parseInt(arguments.get(6)),
                        Integer.parseInt(arguments.get(7)));
                this.vehicles.put(arguments.get(2), revenger);
                this.remainingVehicles.add(arguments.get(2));
                break;
            case "Vanguard":
                Vehicle vanguard = new Vanguard(
                        arguments.get(2),
                        Double.parseDouble(arguments.get(3)),
                        new BigDecimal(arguments.get(4)),
                        Integer.parseInt(arguments.get(5)),
                        Integer.parseInt(arguments.get(6)),
                        Integer.parseInt(arguments.get(7)));
                this.vehicles.put(arguments.get(2), vanguard);
                this.remainingVehicles.add(arguments.get(2));
                break;
        }
        return "Created " + arguments.get(1) + " Vehicle - " + arguments.get(2);
    }

    @Override
    public String addPart(List<String> arguments) {
        switch (arguments.get(2)) {
            case "Arsenal":
                Part arsenal = new ArsenalPart(arguments.get(3),
                        Double.parseDouble(arguments.get(4)),
                        new BigDecimal(arguments.get(5)),
                        Integer.parseInt(arguments.get(6)));
                this.vehicles.get(arguments.get(1)).addArsenalPart(arsenal);
                this.parts.put(arguments.get(3), arsenal);
                break;
            case "Shell":
                Part shell = new ShellPart(arguments.get(3),
                        Double.parseDouble(arguments.get(4)),
                        new BigDecimal(arguments.get(5)),
                        Integer.parseInt(arguments.get(6)));
                this.vehicles.get(arguments.get(1)).addShellPart(shell);
                this.parts.put(arguments.get(3), shell);
                break;
            case "Endurance":
                Part endurance = new EndurancePart(arguments.get(3),
                        Double.parseDouble(arguments.get(4)),
                        new BigDecimal(arguments.get(5)),
                        Integer.parseInt(arguments.get(6)));
                this.vehicles.get(arguments.get(1)).addEndurancePart(endurance);
                this.parts.put(arguments.get(3), endurance);
                break;
        }
        return "Added " + arguments.get(2) + " - " + arguments.get(3) + " to Vehicle - " + arguments.get(1);
    }

    @Override
    public String inspect(List<String> arguments) {
        if (this.vehicles.containsKey(arguments.get(1))) {
            return this.vehicles.get(arguments.get(1)).toString();
        } else {
            return this.parts.get(arguments.get(1)).toString();
        }
    }

    @Override
    public String battle(List<String> arguments) {
        String winner = this.battleOperator.battle(this.vehicles.get(arguments.get(1)), this.vehicles.get(arguments.get(2)));
        if (winner.equals(arguments.get(1))) {
            this.vehicles.remove(this.vehicles.get(arguments.get(2)).getModel());
            defeatedVehicles.add(arguments.get(2));
            this.remainingVehicles.remove(arguments.get(2));
        } else {
            this.vehicles.remove(this.vehicles.get(arguments.get(1)).getModel());
            defeatedVehicles.add(arguments.get(1));
            this.remainingVehicles.remove(arguments.get(1));
        }
        return arguments.get(1)
                + " versus " + arguments.get(2) +
                " -> " + winner + " Wins! Flawless Victory!";
    }

    @Override
    public String terminate(List<String> arguments) {
        StringBuilder str = new StringBuilder();
        if (this.remainingVehicles.size() == 0) {
            str.append("Remaining Vehicles: None\n");
        } else {
            str.append("Remaining Vehicles: " + String.join(", ", this.remainingVehicles) + "\n");
        }
        if (this.defeatedVehicles.size() == 0) {
            str.append("Defeated Vehicles: None" + "\n");
        } else {
            str.append("Defeated Vehicles: " + String.join(", ", this.defeatedVehicles) + "\n");
        }
        final int[] currentlyUsedParts = {0};
        this.vehicles.entrySet().stream().
                forEach(x -> {
                    List<Part> toJoin = new ArrayList<Part>((Collection<? extends Part>) x.getValue().getParts());
                    currentlyUsedParts[0] += toJoin.size();
                });
        str.append("Currently Used Parts: " + currentlyUsedParts[0]);
        return str.toString();
    }
}

