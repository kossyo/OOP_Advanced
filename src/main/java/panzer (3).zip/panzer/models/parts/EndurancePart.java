package panzer.models.parts;

import panzer.contracts.HitPointsModifyingPart;

import java.math.BigDecimal;

public class EndurancePart extends BasePart implements HitPointsModifyingPart {

    private int hitPointsModifier;

    public EndurancePart(String model, double weight, BigDecimal price, int additionalParameter) {
        super(model, weight, price);
        this.hitPointsModifier = additionalParameter;
    }

    public int getHitPointsModifier() {
        return this.hitPointsModifier;
    }


}
